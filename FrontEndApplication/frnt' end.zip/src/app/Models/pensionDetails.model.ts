export interface pensionDetails{
    "aadharNumber": String;
    "pensionAmount":Number;
    "serviceCharge":Number;
}