export interface aadharDetails {
  "aadharNumber": String;
  "name": String;
  "dob": String;
  "pan": String;
  "salaryEarned": Number;
  "allowances": Number;
  "classifcation": String;
  "bankName": String;
  "accountNumber": String;
  "banktype": String;
}
