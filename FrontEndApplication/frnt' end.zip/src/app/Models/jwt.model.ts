export interface jwtToken{
    "jwtToken":String;
}