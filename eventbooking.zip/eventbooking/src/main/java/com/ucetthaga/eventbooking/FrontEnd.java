package com.ucetthaga.eventbooking;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.TimePicker;
import javax.swing.JTextPane;

public class FrontEnd {

	private JFrame frmEventBooking;
	private JTextField nameTextBox;
	private JTextField locationTextBox;
	private JTextField mobileTextBox;

	DatePicker datePicker = new DatePicker();
	DatePicker datePicker_1 = new DatePicker();
	TimePicker timePicker = new TimePicker();
	TimePicker timePicker_1 = new TimePicker();

	JTextPane rateValue = new JTextPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrontEnd window = new FrontEnd();
					window.frmEventBooking.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FrontEnd() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEventBooking = new JFrame();
		frmEventBooking.setTitle("Event Booking - Thagapillai");
		frmEventBooking.setBounds(100, 100, 565, 582);
		frmEventBooking.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEventBooking.getContentPane().setLayout(null);

		JPanel Header = new JPanel();
		Header.setBounds(13, 11, 526, 120);
		frmEventBooking.getContentPane().add(Header);
		Header.setLayout(null);

		JLabel lblNewLabel = new JLabel("Nachathira Events");
		lblNewLabel.setBounds(159, 0, 208, 48);
		Header.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Pristina", Font.BOLD, 30));

		JLabel lblNewLabel_1 = new JLabel("Book Camera for your Events");
		lblNewLabel_1.setBounds(105, 47, 315, 35);
		Header.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Stencil", Font.PLAIN, 20));

		JLabel lblNewLabel_2 = new JLabel("Enter the below details");
		lblNewLabel_2.setBounds(173, 93, 180, 25);
		Header.add(lblNewLabel_2);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));

		JPanel Main = new JPanel();
		Main.setBounds(13, 138, 526, 317);
		Main.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				" Fill the form ", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		frmEventBooking.getContentPane().add(Main);
		Main.setLayout(null);

		JPanel Form = new JPanel();
		Form.setBounds(10, 24, 506, 172);
		Main.add(Form);
		Form.setLayout(null);

		JLabel NameLabel = new JLabel("Name");
		NameLabel.setBounds(27, 11, 46, 14);
		Form.add(NameLabel);

		JLabel DateLabel = new JLabel("Date");
		DateLabel.setBounds(27, 43, 46, 14);
		Form.add(DateLabel);

		JLabel TimeLabel = new JLabel("Time");
		TimeLabel.setBounds(27, 72, 46, 14);
		Form.add(TimeLabel);

		JLabel LocationLabel = new JLabel("Location");
		LocationLabel.setBounds(26, 111, 63, 14);
		Form.add(LocationLabel);

		JLabel MobileLabel = new JLabel("Mobile Number");
		MobileLabel.setBounds(27, 136, 89, 14);
		Form.add(MobileLabel);

		nameTextBox = new JTextField();
		nameTextBox.setBounds(126, 8, 334, 20);
		Form.add(nameTextBox);
		nameTextBox.setColumns(10);

		locationTextBox = new JTextField();
		locationTextBox.setBounds(126, 108, 334, 20);
		Form.add(locationTextBox);
		locationTextBox.setColumns(10);

		mobileTextBox = new JTextField();
		mobileTextBox.setBounds(126, 133, 334, 20);
		Form.add(mobileTextBox);
		mobileTextBox.setColumns(10);

		datePicker.setBounds(126, 34, 155, 29);
		Form.add(datePicker);

		datePicker_1.setBounds(312, 34, 155, 29);
		Form.add(datePicker_1);

		timePicker.setBounds(126, 68, 155, 29);
		Form.add(timePicker);

		timePicker_1.setBounds(312, 68, 155, 29);
		Form.add(timePicker_1);

		JLabel lblNewLabel_3 = new JLabel("From");
		lblNewLabel_3.setBounds(83, 36, 33, 50);
		Form.add(lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("To");
		lblNewLabel_3_1.setBounds(291, 36, 24, 50);
		Form.add(lblNewLabel_3_1);

		JButton bookBtn = new JButton("Book");
		bookBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		bookBtn.setBounds(209, 273, 108, 33);
		Main.add(bookBtn);
		bookBtn.setFont(new Font("Tahoma", Font.BOLD, 20));

		JPanel panel = new JPanel();
		panel.setBounds(10, 207, 506, 47);
		Main.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_4 = new JLabel("Calculated Rate");
		lblNewLabel_4.setBounds(39, 11, 111, 25);
		panel.add(lblNewLabel_4);

		rateValue.setBounds(144, 11, 130, 25);
		panel.add(rateValue);

		JButton calculateBtn = new JButton("Calculate Rate");
		calculateBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double rate = calculateRate(getDatesAndMinDiff());
				rateValue.setText(rate+"rs");
			}
		});
		calculateBtn.setBounds(323, 12, 166, 23);
		panel.add(calculateBtn);

	}

	private long getDatesAndMinDiff() {
		String dateTimeString1 = datePicker.getDate().toString() + " " + timePicker.getTime().toString();
		String dateTimeString2 = datePicker_1.getDate().toString() + " " + timePicker_1.getTime().toString();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		LocalDateTime dateTime1 = LocalDateTime.parse(dateTimeString1, formatter);
		LocalDateTime dateTime2 = LocalDateTime.parse(dateTimeString2, formatter);

		long diffInMinutes = java.time.Duration.between(dateTime1, dateTime2).toMinutes();

		System.out.println("Min " + diffInMinutes);

		return diffInMinutes;

	}

	private double calculateRate(long minDiff) {
		/*
		 * per hour 200rs 60min per day 2500rs 1440min per month 20,000rs 43200min
		 */

		if ((30 <= minDiff) && (minDiff <= 720)) {
			double hr = Math.ceil(minDiff / 60.0);
			System.out.println(hr * 200);
			return (hr * 200);

		} else if ((720 < minDiff) && (minDiff <= 11520)) {
			double day = Math.ceil(minDiff / 1440.0);
			System.out.println(day * 2500);
			return (day * 2500);

		} else if (11520 < minDiff) {
			double mnth = Math.ceil(minDiff / 43200.0);
			System.out.println(mnth * 20000);
			return (mnth * 20000);
		} else {
			return 0;
		}

//		if (minDiff >= 43200) {
//			double mnth = minDiff / 43200.00;
//			System.out.println("Diff in Month : " + mnth);
//			System.out.println("Rate for " + mnth + " Months = " + (mnth * 20000) + " Rs");
//		} else if (minDiff >= 1440) {
//			double days = minDiff / 1440.00;
//			System.out.println("Diff in Days : " + days);
//			System.out.println("Rate for " + days + " Days = " + (days * 2500) + " Rs");
//		} else if (minDiff >= 60) {
//			double hrs = minDiff / 60.00;
//			if(hrs>12) {
//				System.out.println("Diff in Hours : " + hrs);
//				System.out.println("Rate for " + hrs + " Hours = " + (hrs * 200) + " Rs");
//				
//			}else {
//			
//			System.out.println("Diff in Hours : " + hrs);
//			System.out.println("Rate for " + hrs + " Hours = " + (hrs * 200) + " Rs");}
//		} else if (minDiff < 60) {
//			System.out.println("Diff in Minutes : " + minDiff);
//			System.out.println("Rate for " + minDiff + " minutes = 200 Rs");
//		}

	}
}
